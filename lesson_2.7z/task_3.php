<?php
$a = 5;
$b = 3;
function summ($a, $b)
{
        return $a + $b;
}
echo summ($a, $b) . "<br>";

function subtract($a, $b)
{
        return $a - $b;
}
echo subtract($a, $b) . "<br>";

function mult($a, $b)
{
        return $a * $b;
}
echo mult($a, $b) . "<br>";

function divis($a, $b)
{
        return $a / $b;
}
echo divis($a, $b) . "<br>";
