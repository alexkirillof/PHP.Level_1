<?php
$a = rand(1, 15);
switch ($a) {
        case 0:
                print_r(range(0, 15));
                break;
        case 1:
                print_r(range(1, 15));
                break;
        case 2:
                print_r(range(2, 15));;
                break;
        case 3:
                print_r(range(3, 15));
                break;
        case 4:
                print_r(range(4, 15));
                break;
        case 5:
                print_r(range(5, 15));
                break;
        case 6:
                print_r(range(6, 15));
        case 7:
                print_r(range(7, 15));
                break;
        case 8:
                print_r(range(8, 15));
                break;
        case 9:
                print_r(range(9, 15));
                break;
        case 10:
                print_r(range(10, 15));
                break;
        case 11:
                print_r(range(11, 15));
                break;
        case 12:
                print_r(range(12, 15));
                break;
        case 13:
                print_r(range(13, 15));
                break;
        case 14:
                print_r(range(14, 15));
                break;
        default:
                echo '15';
                break;
}
